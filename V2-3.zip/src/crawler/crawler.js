import React, { useState, useEffect } from "react";
//import axios from 'axios';
import CrawlerService from "../api/crawler";
import Button from "@material-ui/core/Button";
import PaginationTableComponent from "../components/table";
import BarChart from "../components/charts/barChart.js";
import LineChart from "../components/charts/lineChart.js";
import DoughnutChart from "../components/charts/doughnutChart.js";
import { Grid } from "@material-ui/core";
import GetAppIcon from "@material-ui/icons/GetApp";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import PublishIcon from "@material-ui/icons/Publish";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  input: {
    display: "none",
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

function Crawler() {
  //     const [data, setData] = useState({ hits: [] });
  const [response, setResponse] = useState();
  const [dataCharts, setDataCharts] = useState({ labels: [], data: [] });
  const classes = useStyles();

  const setChartData = (name) => {
    const data = response.reduce(
      (prev, cur) => {
        const i = prev.labels.findIndex((item) => item === cur[name]);
        if (i > -1) {
          prev.data[i]++;
          return prev;
        } else {
          prev.labels.push(cur[name]);
          prev.data.push(1);
          return prev;
        }
      },
      { labels: [], data: [] }
    );
    setDataCharts(data);
  };

  const startCrawler = async () => {
    try {
      const res = await CrawlerService.startCrawler();
      setResponse(JSON.parse(res.data.data));
    } catch (error) {
      console.log("Network Error", error, error.toJson?.(), error.response);
    }
  };

  return (
    <div>
      <div>
        {!response && (
          <Button variant="primary" onClick={startCrawler}>
            Start Crawler
          </Button>
        )}
        {response && (
          <div className={classes.root}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={12} lg={5} xl={5}>
                <Paper className={classes.paper}>
                  <DoughnutChart dataCharts={dataCharts} />
                </Paper>
              </Grid>
              <Grid item xs={12} sm={12} lg={5} xl={5}>
                <Paper className={classes.paper}>
                  <BarChart dataCharts={dataCharts} />
                </Paper>
              </Grid>
              <Grid item xs={12} sm={12} lg={2} xl={2}>
                <Paper className={classes.paper} style={{ height: "100%" }}>
                  <input
                    accept="*"
                    className={classes.input}
                    id="contained-button-file"
                    multiple
                    type="file"
                  />
                  <label htmlFor="contained-button-file">
                    <Button variant="outlined" color="primary" component="span">
                      Upload
                      <PublishIcon />
                    </Button>
                  </label>
                  <Button
                    href={CrawlerService.downloadSpecification}
                    variant="contained"
                    color="primary"
                  >
                    Download <GetAppIcon />
                  </Button>
                </Paper>
              </Grid>
            </Grid>
            <Grid
              item
              xs={12}
              sm={12}
              lg={12}
              xl={12}
              style={{ display: "block", width: "100%", overflow: "auto" }}
            >
              <PaginationTableComponent
                data={response || {}}
                onColumnClick={setChartData}
              />
            </Grid>
          </div>

          /* <Box>
            <Grid
              container
              direction="column"
              justify="center"
              alignItems="center"
            >
              {dataCharts.data.length > 0 && (
                <Grid container item>
                  <Grid item>
                    <BarChart dataCharts={dataCharts} />
                  </Grid>
                  <Grid item>
                    <DoughnutChart dataCharts={dataCharts} />
                  </Grid>
                  <Grid item>
                    <LineChart dataCharts={dataCharts} />
                  </Grid>
                </Grid>
              )}
              <Grid item>
                <Link href={CrawlerService.downloadSpecification}>
                  Download Specification.xlsx
                </Link>
              </Grid>
              <Grid
                item
                style={{ display: "block", width: "100%", overflow: "auto" }}
              >
                <PaginationTableComponent
                  data={response || {}}
                  onColumnClick={setChartData}
                />
              </Grid>
            </Grid>
          </Box> */
        )}
      </div>
    </div>
  );

  //     useEffect(async () => {
  //       const result = await axios(
  //         '/api/crawler',
  //       );

  //       setData(result.data);
  //     });

  //     return (
  //       <ul>
  //         {data.hits.map(item => (
  //           <li key={item.objectID}>
  //             <a href={item.url}>{item.title}</a>
  //           </li>
  //         ))}
  //       </ul>
  //     );
}

export default Crawler;
